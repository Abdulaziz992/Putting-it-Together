import logo from './logo.svg';
import './App.css';

// import PersonCard from "./components/PersonCard"
import HomePage from "./components/HomePage"


function App() {
  return (
    <div className="App">
        <HomePage />
    </div>
  );
}

export default App;
