import React from "react";

class PersonCard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
    };
    this.incrementCounter = this.incrementCounter.bind(this);
  }

  incrementCounter() {
    // const newCounterValue = this.state.counter + 1;
    // const newStateObject = {
    //   counter: newCounterValue,
    // };

    // this.setState(newStateObject);
    this.setState({ counter: this.state.counter + 1 });
  }

  render() {
    return (
      <div>
        <h1>
          {this.props.name}, {this.props.lastname}
        </h1>
        <h3> Age:{this.props.age + this.state.counter}</h3>
        <h3>Hair Color:{this.props.hiarColor}</h3>
        <button onClick={this.incrementCounter}>
          {" "}
          Birthday Boutton for {this.props.name}, {this.props.lastname}{" "}
        </button>
      </div>
    );
  }
}

export default PersonCard;
