import React from "react";
import PersonCard from "./PersonCard";

class HomePage extends React.Component {
  render() {
    return (
      <>
        <PersonCard
          name={"Jon"}
          lastname={"Doe"}
          age={45}
          hiarColor={"black"}
        />
        <PersonCard
          name={"smith"}
          lastname={"John"}
          age={88}
          hiarColor={"Brown"}
        />
      </>
    );
  }
}

export default HomePage;
